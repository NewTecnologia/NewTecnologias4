
// Exportar CSV de leads (se existir)
function exportToCsv(filename, rows){
  const processRow = function (row) {
      return row.map(v => {
        let innerValue = v===null? '' : v.toString();
        if (v instanceof Date) innerValue = v.toLocaleString();
        if (/[",\n]/.test(innerValue)) innerValue = '"' + innerValue.replace(/"/g, '""') + '"';
        return innerValue;
      }).join(',') + '\n';
  };
  let csvFile = '';
  rows.forEach(r => { csvFile += processRow(r); });
  const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
}

// Máscaras
function maskCPF(v){ v=v.replace(/\D/g,''); v=v.replace(/(\d{3})(\d)/,'$1.$2'); v=v.replace(/(\d{3})(\d)/,'$1.$2'); v=v.replace(/(\d{3})(\d{1,2})$/,'$1-$2'); return v; }
function maskCEP(v){ v=v.replace(/\D/g,''); v=v.replace(/(\d{5})(\d)/,'$1-$2'); return v; }
function maskPhone(v){ v=v.replace(/\D/g,''); if(v.length>11) v=v.slice(0,11); var ddd=v.slice(0,2); var n1=v.slice(2,3); var p1=v.slice(3,7); var p2=v.slice(7,11); if(v.length<=2) return '('+v; if(v.length<=3) return '('+ddd+') '+n1; if(v.length<=7) return '('+ddd+') '+n1+' '+p1; return '('+ddd+') '+n1+'-'+p2; }

// Countdown diário
function startDailyCountdown(targetId){
  function nextDeadline(){
    const now=new Date();
    const end=new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    if(end <= now){ end.setDate(end.getDate()+1); }
    return end;
  }
  const el=document.getElementById(targetId);
  if(!el) return;
  let deadline = nextDeadline();
  function tick(){
    const now=new Date();
    const diff = deadline - now;
    if(diff<=0){ deadline = nextDeadline(); }
    const t = Math.max(0, deadline - now);
    const h = String(Math.floor(t/36e5)).padStart(2,'0');
    const m = String(Math.floor((t%36e5)/6e4)).padStart(2,'0');
    const s = String(Math.floor((t%6e4)/1e3)).padStart(2,'0');
    el.textContent = h+':'+m+':'+s;
  }
  tick();
  setInterval(tick, 1000);
}

// Carousel
function initCarousel(id){
  const el = document.getElementById(id);
  if(!el) return;
  const track = el.querySelector('.carousel__track');
  const items = Array.from(el.querySelectorAll('.carousel__item'));
  const dots  = el.querySelectorAll('.carousel__dot');
  let index = 0;
  function go(i){
    index = (i+items.length)%items.length;
    track.style.transform = 'translateX(' + (-index*100) + '%)';
    dots.forEach((d,k)=>d.classList.toggle('carousel__dot--active', k===index));
  }
  el.querySelector('[data-prev]')?.addEventListener('click', ()=>go(index-1));
  el.querySelector('[data-next]')?.addEventListener('click', ()=>go(index+1));
  dots.forEach((d,k)=>d.addEventListener('click', ()=>go(k)));
  go(0);
}

// Sticky CTA
function initStickyCTA(){
  const bar = document.querySelector('.sticky-cta');
  if(!bar) return;
  function onScroll(){
    const y = window.scrollY || document.documentElement.scrollTop;
    if(y > 600) bar.classList.add('sticky-cta--show');
    else bar.classList.remove('sticky-cta--show');
  }
  onScroll();
  window.addEventListener('scroll', onScroll);
}

document.addEventListener('DOMContentLoaded', ()=>{
  initStickyCTA();
  ['cpf','cep','telefone'].forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    const fn = id==='cpf'?maskCPF : id==='cep'?maskCEP : maskPhone;
    el.addEventListener('input', e => { e.target.value = fn(e.target.value); });
    el.addEventListener('blur', e => {
      const valid = e.target.checkValidity();
      if(!valid){ e.target.classList.add('invalid'); }
      else{ e.target.classList.remove('invalid'); }
    });
  });
});
